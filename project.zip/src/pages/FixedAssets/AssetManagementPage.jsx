// ======================================
// صفحة إدارة الأصول الثابتة
// ======================================

import React from 'react';
import AssetManagement from '../../components/FixedAssets/AssetManagement';

const AssetManagementPage = () => {
  return <AssetManagement />;
};

export default AssetManagementPage;